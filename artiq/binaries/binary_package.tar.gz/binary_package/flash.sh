#!/bin/bash

while getopts "bBrh" opt
do
	case $opt in
		b)
			FLASH_BITSTREAM=1
			;;
		B)
			FLASH_BIOS=1
			;;
		r)
			FLASH_RUNTIME=1
			;;
		*)
			echo "Flashing tool for the ARTIQ project."
			echo ""
			echo "To flash everything, don't use any command line option."
			echo ""
			echo "usage: $0 [-b] [-B] [-r] [-a] [-h]"
			echo "-b  Flash bitstream"
			echo "-B  Flash BIOS"
			echo "-r  Flash ARTIQ runtime"
			echo "-h  Show this help message"
			exit 1
			;;
	esac
done

if [ -z $@ ]
then
	FLASH_RUNTIME=1
	FLASH_BIOS=1
	FLASH_BITSTREAM=1
fi

set -e

if [ "${FLASH_BITSTREAM}" == "1" ]
then
	echo "Flashing FPGA bitstream..."
	xc3sprog -v -c papilio -Ibscan_spi_lx9_papilio.bit artiqminisoc-papilio_pro.bin:w:0x0:BIN
fi

if [ "${FLASH_BIOS}" == "1" ]
then
	echo "Flashing BIOS..."
	xc3sprog -v -c papilio -Ibscan_spi_lx9_papilio.bit bios.bin:w:0x60000:BIN
fi

if [ "${FLASH_RUNTIME}" == "1" ]
then
	echo "Flashing ARTIQ runtime..."
	xc3sprog -v -c papilio -Ibscan_spi_lx9_papilio.bit runtime.fbi:w:0x70000:BIN
fi
echo "Done."
