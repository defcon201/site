#!/bin/bash

while getopts "bBra" opt
do
	case $opt in
		b)
			FLASH_BITSTREAM=1
			;;
		B)
			FLASH_BIOS=1
			;;
		r)
			FLASH_RUNTIME=1
			;;
		a)
			FLASH_RUNTIME=1
			FLASH_BIOS=1
			FLASH_BITSTREAM=1
			;;
		*)
			echo "usage: $0 [-b] [-B] [-r] [-a]"
			echo "-b  Flash bitstream"
			echo "-B  Flash BIOS"
			echo "-r  Flash ARTIQ runtime"
			echo "-a  Flash everything (bitstream+BIOS+runtime)"
			exit 1
	esac
done

set -e

if [ "${FLASH_BITSTREAM}" == "1" ]
then
	echo "Flashing FPGA bitstream..."
	xc3sprog -v -c papilio -Ibscan_spi_lx9_papilio.bit artiqminisoc-papilio_pro.bin:w:0x0:BIN
fi

if [ "${FLASH_BIOS}" == "1" ]
then
	echo "Flashing BIOS..."
	xc3sprog -v -c papilio -Ibscan_spi_lx9_papilio.bit bios.bin:w:0x60000:BIN
fi

if [ "${FLASH_RUNTIME}" == "1" ]
then
	echo "Flashing ARTIQ runtime..."
	xc3sprog -v -c papilio -Ibscan_spi_lx9_papilio.bit runtime.fbi:w:0x70000:BIN
fi
echo "Done."
